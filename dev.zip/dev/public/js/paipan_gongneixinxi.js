const gongweiOverlay = document.querySelectorAll('[data-gongwei-overlay]');

gongweiOverlay.forEach((overlay, i) => {
    overlay.addEventListener('click', () => {});
});
